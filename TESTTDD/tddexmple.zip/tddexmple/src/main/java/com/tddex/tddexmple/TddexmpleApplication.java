package com.tddex.tddexmple;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TddexmpleApplication {

	public static void main(String[] args) {
		SpringApplication.run(TddexmpleApplication.class, args);
	}

}
