import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TestOne {

	public static Address getAddressFromString(String addressString){
		Address address= new Address();
		int idx = addressString.toUpperCase().indexOf("NO ");
		if(idx!= -1){
			 address.setHousenumber(addressString.substring(idx,addressString.length()).trim());
			 address.setStreet(addressString.substring(0,idx).trim());
			 return address;
		}
		addressString=addressString.replaceAll(",", "").trim();
		String regex="\\b\\d+\\s?[a-zA-Z]?\\b";
		Pattern pattern = Pattern.compile(regex); 
		Matcher matcher = pattern.matcher(addressString); 
		   
		   if (matcher.find()) {
			 address.setHousenumber(matcher.group().trim());
			 idx = addressString.indexOf(address.getHousenumber().trim());
			   
	        } 
		   address.setStreet(idx <1 ? addressString.substring(idx+address.getHousenumber().length(),addressString.length()):addressString.substring(0,idx));
		   address.setStreet(address.getStreet().trim());
		   return address;
	}
	public static void main(String[] args) {
		
		Function<String, Address> mapFunc= (String s)->getAddressFromString(s);
		Path path=Paths.get(System.getProperty("user.dir"), "inputStrings.txt");
		if(args.length>0 ){
			path = Paths.get(System.getProperty("user.dir"), args[0]);
		}
		try(PrintWriter pw= new PrintWriter(Paths.get(System.getProperty("user.dir"),"outputJson.json").toFile())) {
			
			Files.readAllLines(path).stream().map( mapFunc).forEach(address->{
				System.out.println(address);
				pw.println(address.toString()+",");
			});
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("File Not Found ::"+path.toString());
		}
	}
	
}
