
public class Address {

	private String street;
	private String housenumber;
	
	public Address(){
		
	}
	
	public Address(String street, String housenumber) {
		super();
		this.street = street;
		this.housenumber = housenumber;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getHousenumber() {
		return housenumber;
	}
	public void setHousenumber(String housenumber) {
		this.housenumber = housenumber;
	}
	
	@Override
	public String toString() {
		return "{\"street\":\""+ street + "\", \"housenumber\":\"" + housenumber+"\"}" ;
	}
}

